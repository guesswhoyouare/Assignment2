import java.io.IOException;


public class Main2014302580199 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		GetHtml getHtml = new GetHtml();
		getHtml.getHtmlFile2014302580199();
	}

}
