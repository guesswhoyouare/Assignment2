import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.*;
import org.jsoup.select.Elements;




public class GetHtml {
	
	public void getHtmlFile2014302580199() throws IOException
	{
		// create a File to store
		String FileName = "information.txt";
		File fName = new File(FileName);
		// write data to file
		FileWriter fw = new FileWriter(fName);
		BufferedWriter bw = new BufferedWriter(fw);
		// set the URL
		String URL = 
				"http://staff.whu.edu.cn/show.jsp?lang=cn&n=Chen%20Sheng%20Li";
		// set the connection
		Document doc = Jsoup.connect(URL).get();
		Elements contents = doc.getElementsByTag("p");
		
		Elements contents1 = doc.getElementsByTag("h1");
		for(Element content1:contents1)
		{
			String str = content1.toString();
			Pattern p =
					Pattern.compile("<h1.*?</h1>");
			Matcher m = p.matcher(str);
			while(m.find())
			{	
				bw.write(" ��ʦ����: ");
				bw.write(m.group().replaceAll("<.*?>", "") + "\r\n");
			}
		}
		
		for(Element content:contents)
		{
			String str = content.toString();
			// use the regular to match the email
			Pattern pattern1 = Pattern.compile("\\w*@(\\w|\\.)*");
			Matcher matcher1 = pattern1.matcher(str);
			// use the regular to match the TEL
			Pattern pattern2 = Pattern.compile("[0-9]{3}\\-[0-9]{8}");
			Matcher matcher2 = pattern2.matcher(str);
			// use the regular to match the PersonalProfile
			Pattern pattern3 = Pattern.compile("<p style.*?</p>");
			Matcher matcher3 = pattern3.matcher(str);
			// use the regular to match the ResearchDirection
			Pattern pattern4 = Pattern.compile("<br>.*?<br>");
			Matcher matcher4 = pattern4.matcher(str);
			// cout
			while(matcher1.find())
			{
				bw.write(" ����: ");
				bw.write(matcher1.group() + "\r\n");
			}
			while(matcher2.find())
			{
				bw.write(" �绰: ");
				bw.write(matcher2.group() + "\r\n");
			}
			while(matcher3.find())
			{
				bw.write(" ���˼���: ");
				bw.write(matcher3.group().replaceAll("<.*?>", "") + "\r\n");
			}
			while(matcher4.find())
			{
				bw.write(matcher4.group().replaceAll("<.*?>","") + "\r\n");
			}
		}
		bw.close();
	}
	
}
